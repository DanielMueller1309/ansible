commit 3127cb4611dfc60c562f2e5c3f3cdf1f8b758545
Author: Larry Smith Jr <mrlesmithjr@gmail.com>
Date:   Thu Sep 24 14:58:44 2020 -0400

    Added new files based on Cookiecutter template

commit 30ab7e03040ef55b8aef6b94287379d3329d8df3
Author: Larry Smith Jr <mrlesmithjr@gmail.com>
Date:   Thu Sep 24 14:57:55 2020 -0400

    Updated files based on Cookiecutter template

commit 1f2f36f1e684735b2b553592986a6c7da8dbd501
Author: Larry Smith Jr <mrlesmithjr@gmail.com>
Date:   Mon Apr 9 13:34:28 2018 -0400

    Cleaned up variables

commit f7f2318c96a26a845ce54daf0242629d7057a8df
Author: Larry Smith Jr <mrlesmithjr@gmail.com>
Date:   Sat Apr 7 01:02:06 2018 -0400

    first commit
